package com.example.event

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
